﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace Boxing.Api.Handlers
{
    public class FilterConfig
    {
        public static void RegisterFilters(HttpConfiguration config)
        {
        }
    }
}
