﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxingWebApp.ViewModels
{
    public class MatchesListViewModel
    {
        public List<MatchesListItem> Items { get; set; }
    }
}
