﻿using System.Collections.Generic;

namespace BoxingWebApp.ViewModels
{
    public class PredictionsListViewModel
    {
        public List<PredictionsListItem> Items { get; set; }
    }
}
