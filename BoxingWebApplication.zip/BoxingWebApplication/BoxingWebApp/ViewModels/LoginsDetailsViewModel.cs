﻿namespace BoxingWebApp.ViewModels
{
    public class LoginsDetailsViewModel : LoginsListItem
    {
        public LoginsDetailsViewModel()
        {

        }
    }
}
