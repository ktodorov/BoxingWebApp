﻿namespace BoxingWebApp.ViewModels
{
    public class PredictionsDetailsViewModel : PredictionsListItem
    {
        public PredictionsDetailsViewModel()
        {

        }
    }
}
