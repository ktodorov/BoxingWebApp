﻿namespace Boxing.Contracts
{
    public sealed class Unit
    {
        public static readonly Unit Value = new Unit();
    }
}
