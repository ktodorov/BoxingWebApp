﻿namespace Boxing.Core.Sql.Configurations
{
    public class BoxerEntity
    {
        //public BoxerEntity()
        //{
        //    Matches = new HashSet<MatchEntity>();
        //}

        public int Id { get; set; }

        public string Name { get; set; }

        //public virtual HashSet<MatchEntity> Matches { get; set; }
    }
}
